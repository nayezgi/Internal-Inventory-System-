var express = require('express');
var router = express.Router();
var db = require("./db");
var common = require('./common');

var validateUser = function (user) {
    var isValid = true;
    var error = {};

    if (!user.firstName) {
        error.firstName = "First name should be provided";
        isValid = false;
    }

    if (!user.lastName) {
        error.lastName = "Last name should be provided";
        isValid = false;
    }

    if (!user.username) {
        error.username = "Username should be provided";
        isValid = false;
    }

    if (!user.password) {
        error.password = "Password should be provided";
        isValid = false;
    }

    return {
        isValid: isValid,
        errorMessage: error
    };
};

router.get('/', function (req, res) {
    db.getAllUsers(
        function (data) {
            console.log(data);
            res.json(data);
        }
    );
});

router.post("/register", function (req, res) {
    var result = validateUser(req.body);

    if (result.isValid) {
        db.registerUser(req.body, function () {
            res.status(200);
            res.json({
                message: "Succefully registered!"
            });
        }, function () {
            res.status(500);
            res.json({
                message: "Username is already taken!"
            });
        });
    } else {
        res.status(400);
        res.json({
            message: result.errorMessage
        });
    }
});

router.post("/login", function (req, res) {
    var loginRequest = req.body;

    db.getLogin(req.body.username, function (logins) {
        var login = logins[0];
        if (login) {
            if (login.password === loginRequest.password) {
                req.session.employeeId = login.id;
                req.session.username = login.username;
                req.session.role = login.role;

                res.status(200);
                res.json({
                    message: "Succefully logedin!",
                    role: login.role
                });
            } else {
                res.status(401);
                res.json({
                    message: "Faild to login!"
                });
            }
        } else {
            res.status(401);
            res.json({
                message: "Faild to login!"
            });
        }
    }, function () {
        res.status(401);
        res.json({
            message: "Faild to login!"
        });
    });
});

router.get('/logout', common.authentication, function (req, res) {
    req.session.destroy();
    res.status(200);
    res.json({
        message: "Succesfully loged out."
    });
});

module.exports = router;