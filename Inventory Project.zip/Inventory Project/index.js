var express = require('express');
var bodyParser = require('body-parser');
var multer = require('multer');
var upload = multer();
var cookieParser = require('cookie-parser');
var session = require('express-session');

var app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(upload.array());

var users = require('./users.js');
var products = require('./products.js');
var requests = require('./requests.js');

app.use(session({
    secret: "VJT2DjX76d5jyyRj",
    resave: true,
    saveUninitialized: true
}));

app.use('/users', users);
app.use('/products', products);
app.use('/requests', requests);
app.use(express.static('static'));

app.use(cookieParser());

app.listen(3000)
