var express = require('express');
var router = express.Router();
var db = require("./db");
var common = require('./common');

function validate(product) {
    var result = {
        isValid: true,
        errorMessage: {}
    };

    if (!product.name) {
        result.isValid = false;
        result.errorMessage.name = "Name is required";
    }

    if (product.quantity <= 0) {
        result.isValid = false;
        result.errorMessage.quantity = "Qunantity should be greater 0";
    }

    if (!product.condition) {
        result.isValid = false;
        result.errorMessage.condition = "Condition is required";
    }

    return result;
}

router.post("", common.authentication, function (req, res) {
    var validation = validate(req.body);

    if (validation.isValid) {
        db.addProduct(req.body, function () {
            res.status(200);
            res.json({
                message: "Succefully registered!"
            });
        }, function () {
            res.status(400);
            res.json({
                message: validation.errorMessage
            });
        });
    } else {
        res.status(400);
        res.json({
            message: validation.errorMessage
        });
    }
});

router.get("/search", common.authentication, function (request, response) {
    var keyWord = request.query.keyWord;
    db.searchProducts(keyWord, function (data) {
        response.status(200);
        response.json(data);
    });
});

router.get("", common.authentication, function (req, res) {
    db.getAllProducts(function (data) {
        console.log(data);
        res.json(data);
    }, function () {

    });
});

module.exports = router;