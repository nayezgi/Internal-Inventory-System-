var auth = function (req, res, next) {
    if (req.session && req.session.username) {
        console.log("allowed to access")
        return next();
    }

    res.sendStatus(401);
};

module.exports = {
    authentication: auth
};