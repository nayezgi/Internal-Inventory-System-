var sql = require("mssql");

var config = {
    user: 'sa',
    password: 'admin123',
    server: 'nayezgi-P\\SQLEXPRESS',
    database: 'IMS'
};


sql.connect(config, function (err) {
    if (err) {
        errorFunc(err);
    } else {
        console.log("Connected to db...")
    }
});

function connectAndExecuteQuery(query, fun, errorFunc) {
    fun = fun ? fun : function () {};
    errorFunc = errorFunc ? errorFunc : function () {};
    // create Request object
    var request = new sql.Request();

    request.query(query, function (err, record) {
        console.log(record);
        if (err) {
            errorFunc(err);
        } else {
            console.log("query completed...");
            fun(record.recordset);
        }
    });
}

module.exports = function () {
    var users = [];
    var requests = [{
            id: 1,
            status: "COMPLETE",
            employeeId: "3755928",
            product: {
                id: 1,
                name: "Dell XPS 15",
                quantity: 1,
                description: "1TB SSD, 32 GB, Touchscreen",
                condition: "New"
            }
        },
        {
            id: 2,
            status: "APPROVED",
            employeeId: "3755828",
            product: {
                id: 2,
                name: "Mouse",
                quantity: 1,
                description: "",
                condition: "New"

            }
        },
        {
            id: 3,
            status: "APPROVED",
            employeeId: "3755928",
            product: {
                id: 3,
                name: "Keyboard",
                quantity: 1,
                description: "Wwirless",
                condition: "Used"
            }
        }
    ];

    var products = [{
            id: 1,
            name: "Dell XPS 15",
            quantity: 14,
            description: "1TB SSD, 32 GB, Touchscreen",
            condition: "New"
        },
        {
            id: 2,
            name: "Mouse",
            quantity: 200,
            description: "",
            condition: "New"
        },
        {
            id: 3,
            name: "Keyboard",
            quantity: 74,
            description: "Wwirless",
            condition: "Used"
        }

    ];

    return {
        registerUser: function (user, success, errorFunc) {
            var isUernameTaken = "SELECT COUNT(*) FROM EMPLOYEE WHERE username = '" + user.username + "'";

            connectAndExecuteQuery(isUernameTaken, function (data) {
                if (data > 0) {
                    errorFunc("Username is taken");
                    return;
                }
                var query = "INSERT INTO EMPLOYEE( firstName, lastName , employeeId , username, password ) VALUES('" +
                    user.firstName + "', '" + user.lastName + "', '" + user.employeeId + "', '" +
                    user.username + "', " + user.password + ")";
                connectAndExecuteQuery(query, success, errorFunc);

            });
        },
        getAllUsers: function (success, errorFunc) {
            var query = "SELECT *FROM EMPLOYEE";
            connectAndExecuteQuery(query, success, errorFunc);
        },
        addProduct: function (product, success, errorFunc) {
            var query = "INSERT INTO PRODUCT (name,quantity,description,condition) VALUES('" +
                product.name + "', " +
                product.quantity + ", '" +
                product.description + "', '" +
                product.condition + "')";
            connectAndExecuteQuery(query, success, errorFunc)
        },
        getAllProducts: function (success, errorFunc) {
            var query = "SELECT *FROM PRODUCT";
            connectAndExecuteQuery(query, success, errorFunc);
        },
        searchProducts: function (keyWord, success, errorFunc) {
            var query = "SELECT *FROM PRODUCT WHERE name like '%" + keyWord + "%'";
            connectAndExecuteQuery(query, success, errorFunc);
        },
        //TODOA
        requestProduct: function (request) {
            requests.push(requset);
            return true;
        },
        getAllRequest: function (success, errorFunc) {
            var query = "SELECT P.id as id, E.id as employeeId, R.id as requestId, R.quantity as quantity, E.employeeId as employeeId, R.status as status, P.name as name, P.description as description, P.condition as condition FROM REQUEST R INNER JOIN PRODUCT P ON R.product = P.id INNER JOIN EMPLOYEE E on E.id = R.requestedBy; ";
            connectAndExecuteQuery(query, success, errorFunc);
        },
        completeRequest: function (requestId, success, errorFunc) {
            var query = "UPDATE REQUEST SET status='COMPLETE' WHERE id = " + requestId;
            connectAndExecuteQuery(query, success, errorFunc);
        },
        cancelRequest: function (requestId, success, errorFunc) {
            var query = "UPDATE REQUEST SET status='CANCELED' WHERE id = " + requestId;
            connectAndExecuteQuery(query, success, errorFunc);
        },
        approveRequest: function (requestId, success, errorFunc) {
            var query = "UPDATE REQUEST SET status='APPROVED' WHERE id = " + requestId;
            connectAndExecuteQuery(query, success, errorFunc);
        },
        denyRequest: function (requestId, success, errorFunc) {
            var query = "UPDATE REQUEST SET status='DENIED' WHERE id = " + requestId;
            connectAndExecuteQuery(query, success, errorFunc);
        },
        createRequest: function (request, success, errorFunc) {
            var query = 'INSERT INTO REQUEST(quantity,"status","product",requestedBy)VALUES(' +
                request.quantity +
                ",'NEW', " +
                request.id + " ," +
                request.requesterId +
                ")";
            connectAndExecuteQuery(query, success, errorFunc);
        },
        getLogin: function (username, success, errorFunc) {
            var loginQuery = "SELECT  *FROM EMPLOYEE WHERE username = '" + username + "'";
            connectAndExecuteQuery(loginQuery, success, errorFunc);
        }
    };
}();