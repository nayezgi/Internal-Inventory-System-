var express = require('express');
var router = express.Router();
var db = require("./db");
var common = require('./common');

function validate(request) {
    var result = {
        isValid: true,
        errorMessage: ""
    };

    if (request.userId === undefined || request.producId === undefined || request.quantity <= 0) {
        result.isValid = false;
        result.errorMessage = "All fields are required";
    }

    return result;
}

router.post("", common.authentication, function (req, res) {

    var productRequest = req.body;
    var result = validate(productRequest);

    if (result.isValid) {
        var isSuccesful = db.requestProduct(productRequest);

        if (isSuccesful) {
            res.status(200);
            db.registerUser(req.body);
            res.json({
                message: "Succefully requested"
            });
        } else {
            res.status(400);
            res.json({
                message: "Invalid request"
            });
        }
    } else {
        res.status(400);
        res.json({
            message: result.errorMessage
        });
    }
});

router.get("", common.authentication, function (req, res) {
    db.getAllRequest(function (data) {
        res.status(200);
        res.json(data);
    })
});

router.get("/complete", common.authentication, function (req, res) {
    var requestId = req.query.id;
    db.completeRequest(requestId, function (data) {
        res.status(200);
    }, function () {
        res.status(500)
    });
});

router.get("/cancel", common.authentication, function (req, res) {
    var requestId = req.query.id;

    db.cancelRequest(requestId, function (data) {
        res.status(200);
    }, function () {
        res.status(500)
    });
});

router.get("/approve", common.authentication, function (req, res) {
    var requestId = req.query.id;

    db.approveRequest(requestId, function (data) {
        res.status(200);
    }, function (err) {
        res.status(500)
    });
});

router.get("/deny", common.authentication, function (req, res) {
    var requestId = req.query.id;

    db.denyRequest(requestId, function (data) {
        res.status(200);
    }, function () {
        res.status(500)
    });
});

router.post('/request',common.authentication, function(req, res){
    var request = req.body;
    request.requesterId = req.session.employeeId;
    db.createRequest(request, function(data){
        res.status(200);
    }, function(err){
        res.status(500);
    });
});


module.exports = router;